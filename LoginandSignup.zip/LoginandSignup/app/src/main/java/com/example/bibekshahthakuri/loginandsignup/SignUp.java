package com.example.bibekshahthakuri.loginandsignup;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends Activity {
    DatabaseHelper helper = new DatabaseHelper(this);
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
    }

    public void onSignupClick(View v) {
        if (v.getId() == R.id.signupButton) {
            EditText name = (EditText) findViewById(R.id.editTextname);
            EditText email = (EditText) findViewById(R.id.editTextemail);
            EditText username = (EditText) findViewById(R.id.editTextusername);
            EditText password = (EditText) findViewById(R.id.editTextpassword);
            EditText cpassword = (EditText) findViewById(R.id.editTextcpassword);

            String namestr = name.getText().toString();
            String emailstr = email.getText().toString();
            String usernamestr = username.getText().toString();
            String passwordstr = password.getText().toString();
            String cpasswordstr = cpassword.getText().toString();

            if (!passwordstr.equals(cpasswordstr)) {
                //popupmessage
                Toast pass = Toast.makeText(SignUp.this, "Password didn't match.",Toast.LENGTH_SHORT);
                pass.show();
            }
            else{
                //insert the details to database
                contact c= new contact();
                c.setName(namestr);
                 c.setUname(usernamestr);
                c.setEmail(emailstr);
                c.setPass(passwordstr);
                helper.insertContact(c);
            }
        }
    }
}