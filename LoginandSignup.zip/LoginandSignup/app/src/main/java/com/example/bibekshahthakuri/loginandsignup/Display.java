package com.example.bibekshahthakuri.loginandsignup;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.TextView;

public class Display extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);
        String username= getIntent().getStringExtra("Username");
        TextView tv=(TextView)findViewById(R.id.usernametext);
        tv.setText(username);
    }
}
